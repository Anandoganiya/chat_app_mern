import mongoose from "mongoose";

const chatModel = new mongoose.Schema(
  {
    chatName: { type: String, trim: true },
    isGroupChat: { type: Boolean, default: false },
    users: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    latestMessage: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message",
    },
    groupAdmin: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

export interface IChat {
  chatName?: string;
  isGroupChat?: boolean;
  users?: any;
  latestMessage?: string;
  groupAdmin?: string;
}

const Chat = mongoose.model("Chat", chatModel);
export default Chat;
